<?php 
class SiteClass {
	private $conn = ""; 	
	public function __construct(){
	$this->conn=mysqli_connect("localhost","root","root","jazz");
		 
	}	
	
	public function print_SEO($description,$keywords,$title){
	echo"
    <meta name=\"description\" content=\" $description\"/>
    <meta name=\"keywords\" content=\"$keywords\" />
    <title>".$title."</title>
		";
	}
	
	public function print_footer(){
		echo "
		<footer class=\"container py-5\">
		  <div class=\"row\">
			<div class=\"col-12 col-md\">
			  <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" class=\"d-block mb-2\" role=\"img\" viewBox=\"0 0 24 24\"><title>Product</title><circle cx=\"12\" cy=\"12\" r=\"10\"/><path d=\"M14.31 8l5.74 9.94M9.69 8h11.48M7.38 12l5.74-9.94M9.69 16L3.95 6.06M14.31 16H2.83m13.79-4l-5.74 9.94\"/></svg>
			  <small class=\"d-block mb-3 text-body-secondary\">&copy; 2017–2023</small>
			</div>
			<div class=\"col-6 col-md\">
			  <h5>Features</h5>
			  <ul class=\"list-unstyled text-small\">
				<li><a class=\"link-secondary text-decoration-none\" href=\"#\">Cool stuff</a></li>
				<li><a class=\"link-secondary text-decoration-none\" href=\"#\">Random feature</a></li>
				<li><a class=\"link-secondary text-decoration-none\" href=\"#\">Team feature</a></li>
				<li><a class=\"link-secondary text-decoration-none\" href=\"#\">Stuff for developers</a></li>
				<li><a class=\"link-secondary text-decoration-none\" href=\"#\">Another one</a></li>
				<li><a class=\"link-secondary text-decoration-none\" href=\"#\">Last time</a></li>
			  </ul>
			</div>
			<div class=\"col-6 col-md\">
			  <h5>Resources</h5>
			  <ul class=\"list-unstyled text-small\">
				<li><a class=\"link-secondary text-decoration-none\" href=\"#\">Resource name</a></li>
				<li><a class=\"link-secondary text-decoration-none\" href=\"#\">Resource</a></li>
				<li><a class=\"link-secondary text-decoration-none\" href=\"#\">Another resource</a></li>
				<li><a class=\"link-secondary text-decoration-none\" href=\"#\">Final resource</a></li>
			  </ul>
			</div>
			<div class=\"col-6 col-md\">
			  <h5>Resources</h5>
			  <ul class=\"list-unstyled text-small\">
				<li><a class=\"link-secondary text-decoration-none\" href=\"#\">Business</a></li>
				<li><a class=\"link-secondary text-decoration-none\" href=\"#\">Education</a></li>
				<li><a class=\"link-secondary text-decoration-none\" href=\"#\">Government</a></li>
				<li><a class=\"link-secondary text-decoration-none\" href=\"#\">Gaming</a></li>
			  </ul>
			</div>
			<div class=\"col-6 col-md\">
			  <h5>About</h5>
			  <ul class=\"list-unstyled text-small\">
				<li><a class=\"link-secondary text-decoration-none\" href=\"#\">Team</a></li>
				<li><a class=\"link-secondary text-decoration-none\" href=\"#\">Locations</a></li>
				<li><a class=\"link-secondary text-decoration-none\" href=\"#\">Privacy</a></li>
				<li><a class=\"link-secondary text-decoration-none\" href=\"#\">Terms</a></li>
			  </ul>
			</div>
		  </div>
		</footer>
		";
	}
	public function print_nav(){
		echo "
					<nav class=\"navbar navbar-expand-md bg-dark sticky-top border-bottom\" data-bs-theme=\"dark\">
			<div class=\"container\">
				<a class=\"navbar-brand d-md-none\" href=\"index.php\">
				<svg class=\"bi\" width=\"24\" height=\"24\"><use xlink:href=\"#aperture\"/></svg>
				Aperture
				</a>
				<button class=\"navbar-toggler\" type=\"button\" data-bs-toggle=\"offcanvas\" data-bs-target=\"#offcanvas\" aria-controls=\"#offcanvas\" aria-label=\"Toggle navigation\">
				<span class=\"navbar-toggler-icon\"></span>
				</button>
				<div class=\"offcanvas offcanvas-end\" tabindex=\"-1\" id=\"#offcanvas\" aria-labelledby=\"#offcanvasLabel\">
				<div class=\"offcanvas-header\">
					<h5 class=\"offcanvas-title\" id=\"#offcanvasLabel\">Aperture</h5>
					<button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"offcanvas\" aria-label=\"Close\"></button>
				</div>
				<div class=\"offcanvas-body\">
					<ul class=\"navbar-nav flex-grow-1 justify-content-between\">
					<li class=\"nav-item\"><a class=\"nav-link\" href=\"index.php\">
						<svg class=\"bi\" width=\"24\" height=\"24\"><use xlink:href=\"#aperture\"/></svg>
					</a></li>
					<li class=\"nav-item\"><a class=\"nav-link\" href=\"index.php\">Главная</a></li>
					
					<li class=\"nav-item\"><a class=\"nav-link\" href=\"history.php\">История жанра</a></li>
					<li class=\"nav-item\"><a class=\"nav-link\" href=\"artist.php\">Артисты</a></li>
					<li class=\"nav-item\"><a class=\"nav-link\" href=\"tracks.php\">Музыка</a></li>
			
					</ul>
				</div>
				</div>
			</div>
			</nav>
		
		";
	}
	
	 
	public function short_descr(){
		$res=mysqli_query($this->conn,"SELECT id,descr FROM artist ORDER BY id");
		if(mysqli_num_rows($res)>0){
			while($row=mysqli_fetch_row($res)){		
				 
								}
									}
										}
									
	
	public function print_info(){
		$res=mysqli_query($this->conn,"SELECT id,name,descr,photo FROM artist ORDER BY id");
		if(mysqli_num_rows($res)>0){
			while($row=mysqli_fetch_row($res)){
				$descr_path="artist/";   
					$files=scandir($descr_path);
					
					$descr=file_get_contents("$descr_path/$row[2].txt" ,FALSE, NULL, 0, 150);

					$link=str_replace(" ","_",$row[1]);
			   echo " 
			   <div class=\"col\">
			   <div class=\"card\">
			   <a href=\"artist.php?artist=$link \"> <img src=\" artist/photo/$row[3]\" class=\"card-img-top\" alt=\"...\" style=\"width: 350px; border-radius: 21px 21px 0 0;\" ></a>
				 <div class=\"card-body\">
				   <h5 class=\"card-title\">$row[1]</h5>
				   <p class=\"card-text\"> $descr... </p>
				   <p class=\"card-text\">  <a href=\"artist.php?artist=$link \">Читать дальше...</a> </p>
				 </div>
			   </div>
			 </div>
			   ";
			}

 
		}
	}

	public function music(){
		$g_name=$_GET['artist'];
		$artist=str_replace("_"," ",$g_name);
		$result = $this->conn->query("SELECT artist.id, artist.name, artist.photo,songs.trackname,songs.cover FROM artist ,songs WHERE artist.id =songs.artist_id AND artist.name='$artist'" );
		if(mysqli_num_rows($result)>0){
				while($row=mysqli_fetch_row($result)){
					
					echo "<div id='music'><img src='icons/play.svg' class='icon' style=\"width: 40px;\">" . $row[3] ."</div><br>
					<audio class=\"mySong\">
						<source src=\"tracks/<?=$row[3]?>.mp3\">
					</audio>
						<script src=\"js/musicplay.js\"></script>";
				}
		}else{
			echo "<h3>Треков нет</h3>";
		}

	}
	public function all_music(){
		
		$result = $this->conn->query("SELECT artist.id, artist.name, artist.photo,songs.trackname,songs.cover FROM artist ,songs WHERE artist.id =songs.artist_id" );
		if(mysqli_num_rows($result)>0){
				while($row=mysqli_fetch_row($result)){
					
					echo "<div id='music'><img src='icons/play.svg' class='icon' style=\"width: 40px;\">" . $row[3] ."</div><br>
					<audio class=\"mySong\">
						<source src=\"tracks/<?=$row[3]?>.mp3\">
					</audio>
						<script src=\"js/musicplay.js\"></script>";
				}
		}else{
			echo "<h3>Треков нет</h3>";
		}
	}
	public function print_links(){
		$g_name=$_GET['artist'];
		
		$artist=str_replace("_"," ",$g_name);
		$result = $this->conn->query("SELECT links.link FROM artist ,links WHERE artist.id =links.artist_id AND artist.name='$artist'" );
		if(mysqli_num_rows($result)>0){
				while($row=mysqli_fetch_row($result)){
					echo "<a href=\"#\" class=\"link-primary link-offset-2 link-underline-opacity-25 link-underline-opacity-100-hover\">$row[0]</a><br><br>";
				}
		}else{
			echo "<h3>Ссылок нет</h3>";
		}

	}
	public function print_artist_info(){
		$g_name=$_GET['artist'];
		$artist=str_replace("_"," ",$g_name);
		$res=mysqli_query($this->conn,"SELECT name,descr,photo FROM artist WHERE name='$artist'");
		if(mysqli_num_rows($res)>0){
			while($row=mysqli_fetch_row($res)){
			if(!empty($row[1])){
				$descr_path="artist/";   
				$files=scandir($descr_path);
				$descr=file_get_contents("$descr_path/$row[1].txt" ,FALSE, NULL,);
				echo "
					<div class=\"artist_wrap\">
					<div class=\"img\">
							<img src=\"artist/photo/$row[2]\" class=\"rounded float-end\" style=\" width:400px; border-radius:100px;\" alt=\"$row[1]\" >
							<div class=\"links\">
							</div>
					</div>
					<div class=\"artistname\">
						<h2>$row[0]</h2>
					</div>
					</div>
					 

					<div id=\"tabs\">
						<ul>
							<li><a href=\"#tabs-1\">История</a></li>
							<li><a href=\"#tabs-2\">Ссылки</a></li>
							<li><a href=\"#tabs-3\">Музыка</a></li>
						</ul>
						<div id=\"tabs-1\">
							<h2>$row[0]</h2>
							<p>$descr </p>
						</div>
						<div id=\"tabs-2\">
							<h2>Соц.сети</h2>
							";
							$this->print_links();
							echo"
						</div>
						<div id=\"tabs-3\">
							<h2>Музыка</h2>
							";
							 $this->music();
							  echo"
						</div>
						</div>
				";
				}
				
			}

 
		}
	}

	public function paggination($dbname){
		 
		$result = $this->conn->query("SELECT * FROM $dbname");
		$row_count = mysqli_num_rows($result);
		// Установка параметров пагинации
		$records_per_page = 5;
		$num_pages = ceil($row_count / $records_per_page);
		$current_page = isset($_GET['page']) ? $_GET['page'] : 1;

		// Выполнение запроса с использованием LIMIT для получения текущей страницы записей
		$start = ($current_page - 1) * $records_per_page;
		$query = "SELECT * FROM $dbname order by id DESC LIMIT $start, $records_per_page";
		$result = $this->conn->query($query);
		echo "<div class='pagination'>";
        for ($i = 1; $i <= $num_pages; $i++) {
            if ($i == $current_page) {
                echo "<strong>$i</strong> ";
            } else {
                echo "<a href='?page=$i'>$i</a> ";
            }
        }
        echo "</div>";
	}


	
}
?> 
